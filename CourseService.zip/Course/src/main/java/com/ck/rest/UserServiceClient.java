package com.ck.rest;
 
import org.springframework.cloud.openfeign.FeignClient;



@FeignClient("USER")
public interface UserServiceClient {
 
}
