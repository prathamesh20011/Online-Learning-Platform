package com.ck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseServiceApplicationTests {

	@Test
	void contextLoads() {
	}
	
	

}
